# Capitec Design System

> Source of truth: **Capitec Web Design System** — Figma file `DS for Claude (TEST).fig`
> Brand / product context: **Capitec Payments**
> Origin: rebuilt from the attached Figma file (mounted as a virtual filesystem under `/Design-System`); the in-Figma footer reads **"Capitec Web Design System"**.

This skill captures the visual + interaction foundations for any Capitec Payments-branded surface: bank portals, internal admin tools, payments dashboards, marketing pages, slide decks. It mirrors the Figma library 1:1 where the .fig had concrete values, and substitutes nearest-equivalent open assets where the .fig referenced symbols whose geometry was not extractable (icons, in particular — see ICONOGRAPHY).

---

## Sources

| Resource | Where | Notes |
|---|---|---|
| Figma library | `DS for Claude (TEST).fig` (mounted, read-only) | 1 page, 97 component frames covering Buttons, Cards, Side-nav, Top-Bar, Alert Banner, Badges, Chips, Date Picker, Dialogs, Lists, Tables, etc. |
| Capitec brand mark | `assets/capitec-c-mark.svg`, `assets/capitec-logo-full.svg` | Lifted from the Figma SYMBOL `Layout=Horizontal, Style=White`. |
| Library badges | `assets/lib-omni.png`, `assets/lib-vuetify.png`, `assets/lib-mui.png` | The Figma component-page header lists Omni, Vuetify and MUI as the libraries this DS is shipped to. |

The Capitec website + Capitec Pay public marketing assets were **not** attached — everything in here was built only from what is in the Figma file. Anything that needed external assumptions (icon set, marketing copy tone) is flagged in-line.

---

## Index — what's in this folder

```
README.md                 ← you are here
SKILL.md                  ← Claude/Agent Skill manifest
colors_and_type.css       ← single source of truth for CSS tokens
fonts/                    ← Nunito Sans variable .ttf (loaded via @font-face)
assets/                   ← logos + library badges
preview/                  ← per-token preview cards (Design-System tab)
ui_kits/
  portal/                 ← Web portal kit (header, side-nav, cards, tables, forms,
                            payment flow, card management — open `index.html`)
  mobile/                 ← Mobile-app kit (status bar, top app bar, list tiles,
                            bottom sheet, payment flow — open `index.html`)
```

> No slide templates were attached, so `slides/` was not built. If you have a
> Capitec slide master, drop it in and ask for a recreation.

---

## Quick-start

```html
<link rel="stylesheet" href="colors_and_type.css">
<!-- Material Symbols substitute for the unresolved icon SYMBOLs in the Figma -->
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0">
<body>
  <h1>Page title</h1>
  <button class="cap-btn cap-btn--filled">Primary action</button>
</body>
```

---

# CONTENT FUNDAMENTALS

The Figma is a component library — it doesn't ship marketing copy, but the slot labels, helper text and microcopy patterns it uses paint a clear voice.

### Voice
- **Plainspoken, transactional, trustworthy.** It's a bank: clarity beats personality. Sentences are short. No exclamation marks, no winks.
- **Second-person, active.** "Select an option", "Enter your ID number", "Choose a payment method" — never "Please select…" and never the first person "We'll…".
- **Lower-case sentence case for everything except product nouns.** Component names in the Figma read `Side nav`, `Top Bar`, `Alert Banner` (sentence case). Section labels read `Building blocks`, `Available in Libraries`. Buttons use sentence case too: **Continue**, **Cancel**, **Save changes** — never `CONTINUE` or `Save Changes`.
- **Use full words, not abbreviations**, in user-facing copy. "Account number" not "Acct. no.".

### Tone & vibe
- **Calm, competent, mid-formal.** Closer to Stripe than Mailchimp. Closer to a teller than a chatbot.
- **No emoji.** Not used anywhere in the Figma. Treat them as out-of-brand.
- **No exclamation marks.** A single "Success" or "Done" — never "Success!".
- **No idiom, no slang, no jokes.** Banking has zero tolerance for ambiguity.

### Casing rules
- `Sentence case` for: page titles, card titles, button labels, menu items, dialog titles.
- `ALL CAPS` is **not** used. The Figma has zero all-caps headings.
- `Title Case` only for product nouns: "Capitec Pay", "Mobile Banking App", "Capitec Web Design System".

### Microcopy patterns (lifted from the Figma)
- Section labels at 14px / weight 400 / `letter-spacing: 0.25px` — e.g. `Building blocks`, `Counter`, `Dot`, `Light Scheme`.
- Card titles at 18px / weight 700 — e.g. `Filled Button`, `Content Card`, `Surface Card`, `Side nav menu`.
- Helper text starts with the verb: `Select an option`, `Enter the amount`.
- Error states are descriptive, not apologetic: `This field is required`, not `Oops! Looks like…`.
- Definitions in the page header read like dictionary entries: `Segmented buttons help people select options`.

### Numbers, dates, money
- **ZAR-first.** Capitec is a South African bank; default to `R 1 234.56` (space thousands separator, two decimals).
- Times use 24h or 12h based on locale, but never mix; Figma table examples use both formats.
- Phone numbers: `+27 21 941 1377` (international prefix, space-separated groups).

---

# VISUAL FOUNDATIONS

### The big idea
Capitec's design language is **clean, dense and high-contrast.** A single deep-navy (`#0033A0`) carries 100% of the brand voice; everything else is functional neutral or a single semantic alert. There is **no decoration** — no gradients in product UI, no illustrations baked into chrome, no patterned backgrounds. Trust is communicated through space, type weight and a tight blue palette.

### Color
- **Brand primary** — `#0033A0` (rgb 0,51,160). Used for the page hero band at the top of every component spec page in the Figma, the side-nav header and the C-mark navy.
- **Action blue** — `#2F70EF` is the only "primary CTA" color. Pressed = `#2D67D8`, focused = `#1655D1`.
- **Accent red** — `#E61414`. **Reserved for the C-mark.** It is *not* a generic error color — critical errors use `#A5132A` (a muted maroon), not the brand red.
- **Tonal blue** `#D8E3FF` for tonal buttons + filled chips.
- **Neutrals are blueish-grey**, not pure greys: `#1F272E → #4A535C → #6D7885 → #A1ACBA → #CFD5E0 → #E4E8F1 → #F0F3FA → #F8FAFD`.

### Type
- **Nunito Sans** for everything. Weights in use: **400 / 500 / 600 / 700 / 900**.
- The variable font ships in `fonts/NunitoSans-Variable.ttf` (full 200–900 weight axis + YTLC/opsz/wdth). Loaded via `@font-face` in `colors_and_type.css` — no Google Fonts dependency.
- Tabular numerics: same font, with `font-feature-settings: 'tnum'` / `font-variant-numeric: tabular-nums`.
- Display sizes the Figma actually uses: 72 / 56 / 32 / 24 / 18 / 16 / 14 / 12 / 9.
- Body line-height ratio ≈ 1.5; headings ≈ 1.2.
- **Letter-spacing only on small labels** (14px @ `+0.25px`). Headings are neutral tracking.

### Spacing & layout
- **4-px grid.** The library ships a literal `.1.5px Grid` component used as ruler scaffolding in dev mode.
- Card inner padding is `20px` on the sides, `60px` top (to leave room for the floating card label) and `28px` bottom.
- Section-header height in the spec pages is exactly **210 px** (52 top padding + 88 line height + 70 bottom padding).
- **Layouts are absolutely positioned in the .fig**, but the conceptual grid is 12-col / 24-px gutter for desktop and a single-column 16-px gutter for mobile (inferred from the breakpoint components).

### Background treatments
- **Flat white** is the default page surface.
- **`#F8FAFD`** for panels nested *inside* white pages (preview wells, code blocks).
- **`#F0F3FA`** for raised surface cards.
- **No gradients.** No textures. No patterns. No hand-drawn illustrations anywhere in this Figma.
- **No full-bleed photography** in the system itself — placeholder slots exist (`MediaTypeImage…`) but the slot is filled with a flat fill in every spec.

### Radii
- **Cards / panels** — `16px`.
- **Inner surfaces / state-layers** — `4–5px`.
- **Buttons + chips + pills + segmented buttons** — `100px` (full pill).
- **Dialogs** — `24px`.
- **Page-hero top corners** — `60px 60px 16px 16px` (this is a spec-page conceit and shouldn't be carried into product surfaces).

### Borders
- **Hairline `1px solid #CFD5E0`** everywhere borders are needed (card outline, table rule, divider, text-field rest state).
- **Dashed `1px dashed #CFD5E0`** for empty-state / drop-zone wells.
- **Dashed `1px dashed #9747FF`** is a **dev-mode annotation** only — never ship a violet dashed border in production.
- Focus rings = solid 2px `#1655D1`, offset 2.

### Shadows
- One recipe: **`0 1px 2px rgba(0,51,160,0.15)`**. Scaled up for raised states (`0 4px 12px` for menus, `0 8px 24px` for dialogs) but always the same `rgba(0,51,160,0.15)` colour. No inner shadows.

### Cards
A Capitec card is: white fill, **1px `#CFD5E0` border**, **16px radius**, **`shadow-1` (single drop-shadow at 15% navy)**, padding `20/28/20/28`. Surface variant swaps the fill to `#F0F3FA`. **No coloured left-border accents** — that pattern is not in this system.

### Buttons
- **Filled** — `#2F70EF` fill, white label, 100px pill, 24px horizontal padding, **48px tall** default, 16/700 label.
- **Outlined** — 1px `#2F70EF` stroke, transparent fill, blue label.
- **Tonal** — `#D8E3FF` fill, blue label.
- **Text** — no fill, no border, blue label, same 48-tall hit area.
- **State layer** — every button has an internal state-layer that pulls **`rgba(255,255,255,0.08)`** on hover (over color fills) or **`rgba(31,39,46,0.08)`** on hover (over light fills). Pressed is a darker tint of the fill colour.
- **Disabled** — `rgba(31,39,46,0.12)` fill, `rgba(31,39,46,0.4)` label.
- Labels use **weight 700** (heavier than headings).

### Hover / press / focus
- Hover = swap to the explicit hover token (NOT just opacity); the system has full hover colors baked in for every interactive component.
- Press = a darker tint of the rest state (e.g. `#2F70EF` → `#2D67D8`).
- Focus = a 2-px outer ring of `#1655D1`, never a glow.
- Disabled = 40% opacity on text, 12% opacity on fill (the system uses `rgba(31,39,46,0.12)` and `rgba(31,39,46,0.4)` literally).
- **No "press shrink" / scale-down** — interactions are color-only.

### Motion
- Capitec product motion is **functional and short**: 120–200 ms, `cubic-bezier(0.2, 0, 0, 1)` (Material's "standard" curve).
- **No bouncy springs.** Loaders are an exception: the brand has a custom 4-frame `Loader Capitec` animation that cycles the C-mark through 4 colour states (white → navy → white → red).
- Fades for overlays, slides for drawers, no rotates/scales for entry.

### Transparency & blur
- Scrims use **`rgba(0,0,0,0.4)`** (no blur). Frosted glass is not part of this system.
- State layers use 8–12% opacity overlays for hover / press.

### Imagery vibe
- The Figma doesn't ship product photography. When imagery is needed downstream, treat it as **bright, daylight-warm, real people, no heavy filters, no grain.** Cool / monochrome / desaturated treatments are out-of-brand. (Inferred from Capitec's broader marketing — flag if more specific guidance arrives.)

### Layout rules
- Top-bar / portal header is **fixed** (`PortalHeader` component).
- Side-nav is **collapsible** (272 px expanded, 80 px collapsed — `Property 1=collapse` / `Property 1=expand`).
- Content area pads `48px` from the side-nav edge on desktop, `16px` on mobile.

---

# ICONOGRAPHY

**Substitution flag.** The Figma file references 100+ icon SYMBOLs (`search`, `home`, `edit`, `close`, `arrow-left`, `arrow_drop_down`, `tick`, `star-filled`, `chevron-down`, etc.) but the icon geometry was not extractable — each component renders as a coloured rectangle in the pseudocode. The naming convention (`arrow_drop_down`, `star_filled`, `chevron_right`) and the 24×24 frame size match **Google Material Symbols** exactly, which is also one of the libraries Capitec ships to (the MUI badge in the Figma header confirms this).

**This skill substitutes Material Symbols (Rounded, weight 400) for those icons** and flags it: if you have the real Capitec icon font / sprite, drop it into `assets/icons/` and update `colors_and_type.css`'s icon section. Until then, the substitution is visually close — same metrics, same stroke weight.

```html
<link href="https://fonts.googleapis.com/icon?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet" />
<span class="material-symbols-rounded">search</span>
<span class="material-symbols-rounded">home</span>
```

### Icon rules
- **24×24** is the canonical size. 16 / 20 / 32 exist for inline & display contexts.
- Icons inherit `currentColor` — **never** ship a coloured icon outside the brand red / brand navy on the C-mark itself.
- **No emoji** anywhere in product UI. The Figma uses zero emoji and zero unicode-glyph icons.
- **No PNG icons** — everything is vector.
- The only **PNG raster assets** in the Figma are the three library badges in the page-header (`assets/lib-*.png`) and the Capitec PWA installer screenshot. Treat raster as illustrative-only.
- The **Capitec C-mark** (`assets/capitec-c-mark.svg`) is the only piece of brand iconography — it appears in the portal header at 40×24 inside a navy circle. Don't tint it; the red + navy colours are intentional.

### Logos
- `assets/capitec-c-mark.svg` — the two-colour lozenge mark. Use on light backgrounds.
- `assets/capitec-logo-full.svg` — wordmark + lozenge (white). Use on `#0033A0` hero bands.

---

# CAVEATS for the user

- **Icon geometry** is substituted from Material Symbols Rounded — the user has confirmed this is fine for now. Swap to a canonical Capitec icon font/sprite when one is available; the mappings are documented in `ICONOGRAPHY`.
- **Product context** is inferred to be a payments portal / banking surface. No live product screens were attached. If/when you want the kit to mirror an actual Capitec Pay screen, share screenshots or repo access and I'll tune the kit to match.
