# Handoff: First Generation Properties — Portal

## Overview
FGP is a property-development portal for a small South African investment club (the "First Generation Properties" team). It lets members scout land parcels, run zoning/compliance checks, evaluate build costs ("Cost Oracle"), track live projects, manage a shared capital fund with maker-checker governance, and configure municipal tariffs and team roles. The UI is built on the **Capitec Payments Design System**.

This bundle is the **design reference** for that portal: a working HTML prototype plus this spec. Build it for real in your own codebase.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the intended look and behaviour, **not production code to lift directly**. The prototype is a single "Design Component" (`First Generation Properties.dc.html`) that runs on a small in-house runtime (`support.js`) — that runtime is a prototyping tool, not something to ship.

Your task is to **recreate these designs in the target codebase's environment** using its established patterns and libraries. Per project memory, the real stack is **Next.js (web) + FastAPI (worker)**; build the screens as React components there. If you start fresh, React + Tailwind (or CSS variables mirroring the tokens below) is the most direct path. Do **not** copy the `.dc.html` / `support.js` mechanics.

## Fidelity
**High-fidelity.** Final colours, typography, spacing, component structure, copy, and interactions are all settled and grounded in the Capitec Payments DS. Recreate the UI faithfully using your codebase's component library, mapping the design tokens below to your theme.

## Design system
Everything visual comes from the **Capitec Payments Design System**. The prototype loads its bundle and composes its primitives (`cap-btn`, `cap-card`, `cap-input`, `cap-sidenav`, `cap-topbar`, `cap-alert`, `cap-stat`, chips/badges). In your codebase, use the equivalent Capitec DS components rather than re-styling raw HTML.

Key Capitec rules to honour:
- **Brand navy** `#0033A0`; **action blue** `#2F70EF` (pressed `#2D67D8`, focus ring `#1655D1`). Red `#E61414` is reserved for the C-mark only — critical errors use maroon `#A5132A`.
- **Nunito Sans** everywhere (weights 400/500/600/700/900). Tabular numerics (`font-variant-numeric: tabular-nums`) for money/metrics.
- Cards: white fill, 1px `#CFD5E0` border, **16px radius**, shadow `0 1px 2px rgba(0,51,160,0.15)`. No coloured left-border accents (except the optional "Bold" mood).
- Buttons/chips/pills: **100px radius** (full pill). Dialogs: 24px radius.
- Sentence case for all labels/titles. No emoji. No exclamation marks. ZAR money formatted `R 1 234.56` (space thousands separator).
- Motion 120–200ms, `cubic-bezier(0.2,0,0,1)`. No springs, no press-scale.

## Global chrome
- **Layout:** fixed left side-nav (256px) + main content column. Collapses to a horizontal scrolling nav bar under 860px (mobile).
- **Side-nav:** FGP brandmark + "First Generation / PROPERTIES" wordmark; grouped nav items (Dashboard, Scout, Evaluate, Projects, Capital fund, Tariffs, Settings) using `cap-nav-item`; footer "Built on Capitec DS" with the C-mark SVG.
- **Top bar:** breadcrumb/page title on the left; on the right a **user switcher** (avatar initials + role pill + chevron → dropdown of team members) and notification bell with activity feed.
- **Theme controls:** light/dark mode toggle and a "mood" segmented control — **Classic / Navy / Bold** (`data-mode` and `data-dir` attributes on the root). Navy = navy side-nav; Bold = larger display type + left-accent stat cards.

## Screens / Views

### 1. Dashboard
Overview landing. KPI stat cards (`cap-stat`), pinned project summary, recent activity feed, quick actions into Scout/Evaluate.

### 2. Scout
Lead-discovery list with a **working filter bar** (segmented filter `all / …`), a **search field** (filters by query), and parcel lead cards. Each card shows a **score ring** (44px circle, coloured by score band), address, zone tag, key facts, and links to Parcel Detail. A map panel (`fgp-map`) with a legend and floating chip sits alongside (static treatment in the prototype; back it with a real map e.g. MapLibre).

### 3. Parcel Detail
Single parcel deep-dive: address header, fact grid (`fgp-fact` chips), zoning/dolomite tags, and an **animated 3D massing** preview (CSS-transform isometric block — purely decorative; replace with a real massing/3D viewer or a static render). Buttons to start Evaluate or build the Compliance package.

### 4. Zoning / Compliance package
Generated forms/checklist view for the parcel's municipality and zone, with a vertical timeline (`fgp-tl`) of compliance steps and checkbox states (`fgp-checkbox`).

### 5. Evaluate → Cost Oracle
A form (address, municipality, zone, plot size m², asking price, unit type, unit count) that produces a **Cost Oracle** result: cost breakdown bars (`fgp-bar`), totals, and a feasibility verdict. Unit types: `bachelor / 1bed / 2bed / luxury`. Build rates and bulk-contribution figures come from **Tariffs** and feed this calculation live.

### 6. Projects (list + detail)
List of live projects; three have full data: **Soshanguve Build**, **Noordwyk**, **Karenpark** (each own status, location, timeline, budget). Project detail has an **Edit project** action (role-gated — see roles).

### 7. Capital fund
The governance centerpiece:
- **Contributions** ledger and totals; **Record contribution** action.
- **Maker-checker corrections:** Treasurer/Owner *proposes* an edit or removal of a contribution; another governing member must *co-sign* before it applies.
- **Unanimous goal changes:** a new fund goal must be co-signed by **every active, non-Viewer member** before it takes effect. Co-signing is per-logged-in-user (you sign only as yourself).
- Shareable account details, leaderboard, and milestone progress.

### 8. Tariffs
Editable municipal build rates (per unit type) and bulk contributions (per municipality), plus tariff year. Inputs are **role-gated** (Treasurer/Chairperson only; others see a lock banner and disabled inputs).

### 9. Settings
Notification preferences (email/WhatsApp/weekly/digest toggles), data-source scrapers (toggles), auto-analyze + score-threshold slider, and **Team management** (member list with role selects, remove, and email invite — all gated to Chairperson).

## Roles & permissions (enforced, not cosmetic)
A real "logged-in user" is chosen via the top-bar switcher; capabilities are gated at both UI and handler level.

Capabilities by role:
- **Owner** — everything: record, edit project, edit tariffs, edit settings, manage team, co-sign, propose goal, propose correction.
- **Chairperson** — record, edit project, edit tariffs, edit settings, **manage team**, co-sign. (Cannot propose goal/correction.)
- **Treasurer** — record, edit project, edit tariffs, edit settings, co-sign, **propose goal**, **propose correction**. (Cannot manage team.)
- **Analyst** — record, edit project, edit settings, co-sign. (Tariffs locked; team management hidden.)
- **Viewer** — **read-only**. App-wide "read-only" banner; record/edit/toggle/team controls hidden or disabled; handlers refuse even if invoked.

Governance counting: only **active, non-Viewer** members are counted toward unanimous goal changes and are eligible co-signers. A user can only co-sign as the currently-signed-in user.

Seed team in the prototype: Tlangelani Mkhabela (Treasurer), Thabo Nkosi (Chairperson), Lerato Dube (Analyst, invited).

## Interactions & behaviour
- **Navigation:** SPA-style screen switching via a `screen` state value (`dashboard / scout / parcel / zoning / evaluate / result / projects / projectDetail / capital / tariffs / settings`). Breadcrumb in top bar reflects current screen.
- **Modals:** scrim `rgba(0,0,0,0.4)`, dialog card 24px radius, shadow `0 8px 24px rgba(0,51,160,0.15)`. Used for record contribution, propose correction, set/propose goal.
- **Maker-checker / co-sign:** proposing sets a pending proposal object; each governing member's row shows "Proposed / Co-signed / Your signature needed / Awaiting"; the change commits when all required signatures are collected.
- **Notifications/Activity:** every significant event (contribution, proposal, co-sign, goal change, project edit, invite) pushes a notification into an activity feed.
- **Entry animation:** content panels use a short translateY(8px)→0 fade on screen change.
- **Persistence:** the prototype persists all state to `localStorage` under key `fgp_state_v1`. In production use your real backend/DB instead.
- **Responsive:** ≤860px collapses the side-nav into a horizontal scroll bar and stacks content.

## State management
Core state shape (from the prototype):
- `screen`, `mode` (light/dark), `dir` (classic/navy/bold)
- `currentUser` (drives role enforcement), `userMenuOpen`
- `scoutFilter`, `scoutQuery`, `unit`, `form` (evaluate inputs), `result` / `resultProject`
- `editing`, `projSnap`, `projectOverrides`, `pinnedProject`, `extraProjects`
- `tariffs` { year, rates{bachelor,1bed,2bed,luxury}, bulk{johannesburg,tshwane,ekurhuleni} }
- `settings` { notif* flags, scrapers{…}, autoAnalyze, scoreThreshold, team[{name,email,role,status}] }
- Capital fund: contributions, goal, pending `goalProposal` {proposedBy, newAmount, approvals[]}, pending correction proposal, milestones/leaderboard derived.
- Transient: `recordOpen`/`recordForm`, `goalOpen`, `editOpen`, `invite`, `inviteMsg`, notifications feed.

Derived helpers worth replicating: `currentRole()`, `caps(role)`, `can(cap)`, `signMembers()` (active + non-Viewer), ZAR formatter.

## Design tokens
All tokens come from the Capitec DS (`colors_and_type.css`, copied into this bundle under `capitec-ds/`). Highlights:
- **Brand:** navy `#0033A0`, action blue `#2F70EF`, pressed `#2D67D8`, focus `#1655D1`, tonal blue `#D8E3FF`, C-mark red `#E61414`, error maroon `#A5132A`.
- **Neutrals (light):** `#1F272E / #4A535C / #6D7885 / #A1ACBA / #CFD5E0 / #E4E8F1 / #F0F3FA / #F8FAFD`. Dark-mode neutral ramp is defined in the prototype's `[data-mode="dark"]` block (copy it for parity).
- **Type:** Nunito Sans; sizes 72/56/32/24/18/16/14/12/9; body line-height ~1.5, headings ~1.2; small-label letter-spacing +0.25px.
- **Radii:** cards 16px, inner surfaces 4–5px, buttons/chips/pills 100px, dialogs 24px.
- **Shadows:** base `0 1px 2px rgba(0,51,160,0.15)`; menu `0 4px 12px`; dialog `0 8px 24px` (same navy-15% colour).
- **Borders:** hairline `1px solid #CFD5E0`; dashed `1px dashed #CFD5E0` for empty/drop wells.
- **Motion:** 120–200ms, `cubic-bezier(0.2,0,0,1)`.
- **Money:** ZAR, `R 1 234.56` (space thousands, two decimals).

## Assets
- Capitec C-mark / wordmark SVGs — from the Capitec DS (`capitec-ds/assets/`). Don't tint the C-mark.
- Icons — **Material Symbols Rounded** (weight 400) as the substitute icon set the DS specifies. Swap for a canonical Capitec icon font if you have one.
- No product photography is used; the map and 3D massing are placeholder treatments — back them with real components/data.

## Files
- `First Generation Properties.dc.html` — the full prototype (all screens, logic, styles). Primary reference.
- `support.js` — the prototyping runtime (reference only; do not ship).
- `capitec-ds/` — the Capitec Payments Design System tokens, stylesheets and assets the prototype is built on. Map these into your codebase theme.

Open the prototype by serving this folder and loading `First Generation Properties.dc.html` in a browser.
